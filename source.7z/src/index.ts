import { createTable } from './database/database.controller';
import { entityIntegration, restoreEntity, runEntity } from './integration/integration.controller';

//
// Create table on Big Query
exports.createTable = createTable;

// Restore entities - truncate tables and get with date(0)
exports.restoreEntity = restoreEntity;

// Entity integration
exports.runEntity = runEntity;

//
//  BY TASKS
//
exports.entityIntegration = entityIntegration;
