export type IntegrationRequest = {
  body: {
    entity: string;
    endpoint?: string;
    limit?: number;
    offset?: number;
    startDate?: Date;
    endDate?: Date;
    getType?: string; // create | update
    data?: any;
  };
};
