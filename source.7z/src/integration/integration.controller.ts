import * as functions from 'firebase-functions';
import { IntegrationRequest } from './dto/integration-request';
import { IntegrationService } from './integration.service';

const runtimeOpts = {
  timeoutSeconds: 540,
  memory: '2GB' as const,
};

//
//
// export const integrateCustomers = functions

//
//
//
export const restoreAllEntities = functions
  .runWith(runtimeOpts)
  .https.onRequest(async (request: IntegrationRequest, response: any) => {
    //
    try {
      // Integration
      const integration = new IntegrationService();

      // Accounts
      request.body.entity = 'account';
      await integration.restoreEntity(request);

      // Campaign
      request.body.entity = 'campaign';
      await integration.restoreEntity(request);

      // Deal Stage
      request.body.entity = 'dealStage';
      await integration.restoreEntity(request);

      // Lead
      request.body.entity = 'lead';
      await integration.restoreEntity(request);

      // Opportunity
      request.body.entity = 'opportunity';
      await integration.restoreEntity(request);

      // User Profile
      request.body.entity = 'userProfile';
      await integration.restoreEntity(request);

      //
      response.send('Restore all entities started');
      //
    } catch (error) {
      const errorTyped: any = error;
      functions.logger.error('Erro', { error: errorTyped.message });
      response.status(400).send(errorTyped.message);
    }
  });

//
//
//
export const restoreEntity = functions
  .runWith(runtimeOpts)
  .https.onRequest(async (request: IntegrationRequest, response: any) => {
    //
    try {
      // Integration
      const integration = new IntegrationService();
      await integration.restoreEntity(request);

      //
      response.send('Restore entity started');
      //
    } catch (error) {
      const errorTyped: any = error;
      functions.logger.error('Erro', { error: errorTyped.message });
      response.status(400).send(errorTyped.message);
    }
  });

//
//
export const runEntity = functions
  .runWith(runtimeOpts)
  .https.onRequest(async (request: IntegrationRequest, response: any) => {
    //
    const entity = request.body.entity;

    //
    try {
      // Integration
      const integration = new IntegrationService();

      await integration.runEntity(entity);

      response.send('Entity integration started');
      //
    } catch (error) {
      const errorTyped: any = error;
      functions.logger.error('Erro', { error: errorTyped.message });
      response.status(400).send(errorTyped.message);
    }
  });

//
//
//
export const entityIntegration = functions
  .runWith(runtimeOpts)
  .https.onRequest(async (request: IntegrationRequest, response: any) => {
    //
    try {
      //
      const integration = new IntegrationService();
      await integration.run(request);

      //
      response.send('Entity integration');
    } catch (error) {
      const errorTyped: any = error;
      functions.logger.error('Erro', { error: errorTyped.message });
      response.status(400).send(errorTyped.message);
    }
  });

//
//
// const runtimeEventOpts = {
//   timeoutSeconds: 540,
//   memory: "8GB" as const,
// };
export const eventIntegration = functions
  .runWith(runtimeOpts)
  .https.onRequest(async (request: IntegrationRequest, response: any) => {
    //
    const entity = 'event';

    //
    try {
      // Integration
      const integration = new IntegrationService();

      const startDate = await integration.lastSync(entity);
      const lastSync = new Date();

      const request: IntegrationRequest = {
        body: {
          entity,
          startDate: startDate,
          getType: '',
        },
      };
      await integration.run(request);

      //
      await integration.updateSync(entity, lastSync);

      //
      response.send('Entity integration started');
      //
    } catch (error) {
      const errorTyped: any = error;
      functions.logger.error('Erro', { error: errorTyped.message });
      response.status(400).send(errorTyped.message);
    }
  });
