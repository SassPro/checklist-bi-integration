import { SharpspringAPI } from '../common/sharpspring-api-lib';
import { BigQueryAdapter, BigQueryInsert, BigQueryTruncate } from '../lib/BigQueryAdapter';
import { Task } from '../lib/Task';
import { IntegrationRequest } from './dto/integration-request';
import admin = require('firebase-admin');
import { TenantService } from '../tenant/tenant.service';
import { SchemaRequest, SchemaResponse } from '../tenant/tenant';
import { SHARPSPRING_API_ENTITIES, SharpspringEntity } from '../common/sharpspring-api-entities';

/**
 * Integration Service
 */
export class IntegrationService {
  private projectId: string;
  private integration: string;
  private dataset: string;

  constructor() {
    this.projectId = process.env.PROJECT_ID || '';
    this.integration = process.env.FIRESTORE_INTEGRATION_COLLECTION || '';
    this.dataset = process.env.BIGQUERY_DATASET || 'dataset-name-not-provided-in-env-file';
  }
  /**
   *
   * @param {IntegrationRequest} request request
   * @return {object} ins
   */
  async run(request: IntegrationRequest): Promise<void> {
    //
    const entity = request.body?.entity?.toString().trim() || '';

    // Error
    if (this.dataset === '') {
      const message = { message: 'BIGQUERY_DATASET is not provided in env file' };
      throw message;
    }

    if (entity === '') {
      const message = { message: 'Param entity is required' };
      throw message;
    }

    if (entity === 'event' && request.body.getType === 'update') {
      return;
    }

    try {
      //
      request.body.limit = request.body.limit || 100;
      request.body.offset = request.body.offset || 0;
      request.body.getType = request.body.getType || 'create';

      const startDate = new Date(request.body.startDate || 0);
      const endDate = new Date();
      endDate.setFullYear(2050, 11, 31);

      request.body.startDate = startDate;
      request.body.endDate = endDate;

      //
      const entity = request.body.entity as keyof typeof SHARPSPRING_API_ENTITIES;

      // Entity
      const entityData: SharpspringEntity = SHARPSPRING_API_ENTITIES[entity];

      // Schema
      const schemaReq: SchemaRequest = {
        entity,
      };
      const tenantService = new TenantService();
      const fieldsEntity: SchemaResponse[] = await tenantService.getSchema(schemaReq);

      // buscar dados na Sharp
      const startDateFormat = startDate
        .toISOString()
        .replace(/(?!^)T/g, ' ')
        .replace(/\..+/, '');
      const endDateFormat = endDate.toISOString().replace(/T/, ' ').replace(/\..+/, '');

      const params: any = {
        offset: request.body.offset,
        limit: request.body.limit,
      };

      // Event
      if (entity === 'event') {
        params.where = {
          createTimestamp: startDateFormat,
        };
        //
      } else if (entityData.requestBody === 'where') {
        params.where = {};
        // DateRange
      } else {
        params.startDate = startDateFormat;
        params.endDate = endDateFormat;
        params.timestamp = request.body.getType;
      }

      //
      const body = {
        method: entityData.method,
        params,
        id: `${entityData.method}_${request.body.offset}`,
      };

      const sharpApi = new SharpspringAPI();
      const res = await sharpApi.post(body);

      // Erro na busca do dados na API
      if (res.data?.error?.message) {
        const message = {
          message: `IntegrationService | run | returnAPI > ${res.data.error.message}: 
          ${JSON.stringify(res.data.error)}`,
        };
        throw message;
      }

      // result
      const result = res.data.result[entityData.returnData];

      // // tratar retorno
      const data = result?.map((res: any) => {
        // Event fields
        if (entity === 'event') {
          if (res.eventData) {
            const eventData = typeof res.eventData === 'string' ? JSON.parse(res.eventData) : res.eventData;
            if (eventData) {
              Object.assign(res, eventData);
              // delete unified.eventData;
            }
          } else {
            res.eventData = {};
          }
        }

        const obj: any = {};
        fieldsEntity.map((s: any) => {
          // Event - EventData
          if (entity === 'event') {
            if (s.name == 'eventData') {
              res[s.name] = JSON.stringify(res[s.name]) || '';
            }

            if (s.name == 'opportunity') {
              res[s.name] = res[s.name] ? res[s.name]['id'] : '';
            }
          }

          if (s.type == 'FLOAT64' || s.type == 'INT64' || s.type == 'INT' || s.type == 'INTEGER') {
            obj[s.name] = Number(res[s.name] || 0);
          } else if (s.type == 'TIMESTAMP') {
            obj[s.name] = new Date(res[s.name] || 0);
          } else if (s.type == 'BOOLEAN') {
            obj[s.name] = res[s.name] == 1;
          } else {
            obj[s.name] = res[s.name] || '';
          }
        });
        obj['updated_at'] = new Date().getTime();
        return obj;
      });

      // Se a quantidade de registros retornados for = limite, colocar na fila com o offset atuaslizado
      if (Number(data.length) === Number(request.body.limit) && entity !== 'event') {
        request.body.offset = Number(request.body.offset) + Number(request.body.limit);
        request.body.endpoint = 'entityIntegration';
        await this.addTask(request);
      }

      //
      //
      //
      // Inserir in BigQuery
      //
      while (data.length > 0) {
        //
        const insertData = data.splice(0, 999);

        // Inserir no BigQuery
        const insert: BigQueryInsert = {
          dataset: this.dataset,
          table: entity,
          data: insertData,
        };
        const bq = new BigQueryAdapter();
        await bq.insertAll(insert);
      }

      //
      //
    } catch (error) {
      const errorTyped: any = error;
      const message = {
        message: `IntegrationService | run > ${errorTyped.message}`,
      };
      throw message;
    }
  }

  /**
   *
   * @param {string} tenant tenant
   * @param {string} entity entity
   * @param {string} getType getType
   */
  async runEntity(entity: string): Promise<void> {
    // Error
    if (entity === '') {
      const message = { message: 'Param entity is required' };
      throw message;
    }

    try {
      //
      const startDate = await this.lastSync(entity);

      //
      // Add task - Create Entities
      const request: IntegrationRequest = {
        body: {
          endpoint: 'entityIntegration',
          entity,
          startDate: startDate,
          getType: 'create',
        },
      };
      await this.addTask(request);

      //
      // Add task - Update Entities
      request.body.getType = 'update';
      await this.addTask(request);
      // await this.run(request);

      //
      await this.updateSync(entity, new Date());
      //
    } catch (error) {
      const errorTyped: any = error;
      const message = {
        message: `IntegrationService | runEntity > ${errorTyped.message}`,
      };
      throw message;
    }
  }

  /**
   *
   * @param {IntegrationRequest} req req
   */
  async addTask(req: IntegrationRequest): Promise<void> {
    //
    try {
      //
      req.body.endpoint = req.body.endpoint || 'entityIntegration';

      const taskService = new Task();
      await taskService.createHttpPost(req);
    } catch (error) {
      const errorTyped: any = error;
      const message = {
        message: `IntegrationService | addTask > ${errorTyped.message}`,
      };
      throw message;
    }
  }

  /**
   *
   * @param request BigQueryTruncate
   * @return response
   */
  async truncate(request: BigQueryTruncate) {
    try {
      const bq = new BigQueryAdapter();
      const truncate = await bq.truncateTable(request);

      return truncate;
    } catch (error) {
      const errorTyped: any = error;
      const message = {
        message: `IntegrationService | truncate > ${errorTyped.message}`,
      };
      throw message;
    }
  }

  /**
   *
   * @param {IntegrationRequest} request request
   * @return {string} result
   */
  async restoreEntity(request: IntegrationRequest): Promise<string> {
    const entity = request.body?.entity?.toString().trim() || '';

    // Error
    // Error
    if (this.dataset === '') {
      const message = { message: 'BIGQUERY_DATASET is not provided in env file' };
      throw message;
    }

    if (entity === '') {
      const message = { message: 'Param entity is required' };
      throw message;
    }

    //
    try {
      // Truncate table
      const truncateRequest: BigQueryTruncate = {
        project: this.projectId,
        dataset: this.dataset,
        table: request.body.entity,
      };
      await this.truncate(truncateRequest);

      // Add task - Load Entity
      request.body.endpoint = 'entityIntegration';
      await this.addTask(request);

      //
      return 'Restore entity started';
      //
    } catch (error) {
      const errorTyped: any = error;
      const message = {
        message: `IntegrationService | restoreEntity > ${errorTyped.message}`,
      };
      throw message;
    }
  }

  /**
   *
   * @param {string} entity entity
   * @return {Date} lastSync
   */
  async lastSync(entity: string): Promise<Date> {
    //
    admin.apps.length ? admin.app() : admin.initializeApp();
    const db = admin.firestore();
    //
    try {
      const documentRef = await db.collection(this.integration).doc(entity).get();

      const document = documentRef.data() || {};

      const last = document.lastSync?.seconds * 1000 || 0;

      const res = new Date(last);
      // res.setHours(res.getHours() - 3);

      return res;
    } catch (error) {
      const message = { message: `IntegrationService | lastSync > ${error}` };
      throw message;
    }
  }

  /**
   *
   * @param {string} entity entity
   * @param {Date} lastSync lastSync
   */
  async updateSync(entity: string, lastSync: Date): Promise<void> {
    //
    admin.apps.length ? admin.app() : admin.initializeApp();
    const db = admin.firestore();

    //
    try {
      const document = {
        lastSync,
      };

      await db.collection(this.integration).doc(entity).set(document);
      //
    } catch (error) {
      const message = { message: `IntegrationService | lastSync > ${error}` };
      throw message;
    }
  }
}
