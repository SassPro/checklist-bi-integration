import * as functions from 'firebase-functions';
import { BigQueryInsert } from '../lib/BigQueryAdapter';
import { DatabaseService } from './database.service';

const DATASET = process.env.BIGQUERY_DATASET || 'dataset-name-not-provided-in-env-file';

/**
 *
 * Create Table
 *
 */
export const createTable = functions.https.onRequest(
  async (request: functions.Request, response: functions.Response) => {
    try {
      const entity = request.body?.entity;

      if (DATASET === '') {
        response.status(400).send('BIGQUERY_DATASET is not provided in env file');
        return;
      }

      if (entity === '') {
        response.status(400).send('Param entity is required');
        return;
      }

      const databaseService = new DatabaseService();
      const entidade = await databaseService.createTable({ dataset: DATASET, entity });

      response.send(entidade);
    } catch (error) {
      const errorTyped: any = error;
      const message = `database.controller | createTable > ${errorTyped.message}`;
      response.status(400).send({ message });
    }
  },
);

/**
 *
 *  Insert data in BigQuery
 *
 */
export const bigQueryInsert = functions.https.onRequest(
  async (request: functions.Request, response: functions.Response) => {
    try {
      const entity = request.body?.entity?.toString().trim() || '';
      const data = request.body?.data || [];

      if (DATASET === '') {
        response.status(400).send('BIGQUERY_DATASET is not provided in env file');
        return;
      }

      if (entity === '') {
        response.status(400).send("Param 'entity' is required");
        return;
      }

      if (data.length == 0) {
        response.status(400).send("Param 'data' is required");
        return;
      }

      // Inserir no BigQuery
      const insert: BigQueryInsert = {
        dataset: DATASET,
        table: entity,
        data,
      };

      const databaseService = new DatabaseService();
      const entidade = await databaseService.bigQueryInsert(insert);

      response.send(entidade);
    } catch (error) {
      const errorTyped: any = error;
      const message = `database.controller | createTable > ${errorTyped.message}`;
      response.status(400).send({ message });
    }
  },
);
