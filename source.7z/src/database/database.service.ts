import { BigQueryAdapter, BigQueryCreateTable, BigQueryInsert } from '../lib/BigQueryAdapter';
import { SchemaResponse } from '../tenant/tenant';
import { TenantService } from '../tenant/tenant.service';

type CreateTableRequest = {
  dataset: string;
  entity: string;
};

/**
 * Schema
 */
export class DatabaseService {
  /**
   *
   * @param {EntityRequest} request request
   * @return {object} create
   */
  async createTable(request: CreateTableRequest): Promise<unknown> {
    try {
      //
      const { dataset, entity } = request;

      // Schema
      const tenantService = new TenantService();
      const fields: SchemaResponse[] = await tenantService.getSchema({ entity });

      if (fields.length > 0) {
        fields.push({ name: 'updated_at', type: 'STRING' });
      }

      const req: BigQueryCreateTable = {
        dataset,
        table: entity,
        fields,
      };

      //
      const bqAdapter = new BigQueryAdapter();
      const create = await bqAdapter.createTable(req);
      return create;
    } catch (error) {
      const errorTyped: any = error;
      const message = {
        message: `database.service | createTable > ${errorTyped.message}`,
      };
      throw message;
    }
  }

  /**
   *
   * @param {BigQueryInsert} insert insert
   */
  async bigQueryInsert(insert: BigQueryInsert): Promise<string> {
    //
    try {
      const bq = new BigQueryAdapter();
      await bq.insertAll(insert);
      return 'OK';
    } catch (error) {
      const errorTyped: any = error;
      const message = {
        message: `database.service | bigQueryInsert > ${errorTyped.message}`,
      };
      throw message;
    }
  }
}
