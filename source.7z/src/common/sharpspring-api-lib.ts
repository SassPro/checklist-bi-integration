import { AxiosResponse } from 'axios';
import { httpClient } from '../lib/HttpClient';

/**
 *
 * Sharpspring conection and requests
 */
export class SharpspringAPI {
  //
  private baseUrl = 'http://api.sharpspring.com/pubapi/v1.2/';

  /**
   *
   */
  constructor() {}

  /**
   *
   * @returns {object} headers connections
   */
  getHeaders(): { baseURL: string } {
    try {
      const ACCOUNT_ID = process.env.SHARPSPRING_ACCOUNT_ID;
      const SECRET_KEY = process.env.SHARPSPRING_SECRET_KEY;

      return {
        baseURL: `${this.baseUrl}?accountID=${ACCOUNT_ID}&secretKey=${SECRET_KEY}`,
      };
    } catch (error) {
      const errorTyped: any = error;
      const message = { message: `SharpspringAPI.getHeaders > ${errorTyped.message}` };
      throw message;
    }
  }

  /**
   *
   * @param {object} body
   * @return {object} data
   */
  async post<T>(body: T): Promise<AxiosResponse<any>> {
    try {
      const config = this.getHeaders();
      const http = httpClient(config);

      return http.post('', body);
    } catch (error) {
      const errorTyped: any = error;
      const message = { message: `SharpspringAPI.post > ${errorTyped.message}` };
      throw message;
    }
  }
}
