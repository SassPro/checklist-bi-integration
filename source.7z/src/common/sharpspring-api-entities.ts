export type SharpspringEntity = {
  method: string;
  returnData: string;
  requestBody?: string;
  responseBody?: string;
};

export const SHARPSPRING_API_ENTITIES = {
  account: {
    method: 'getAccountsDateRange',
    returnData: 'account',
    responseBody: 'default',
  },
  campaign: {
    method: 'getCampaignsDateRange',
    returnData: 'campaign',
    responseBody: 'default',
  },
  dealStage: {
    method: 'getDealStagesDateRange',
    returnData: 'dealStage',
    responseBody: 'default',
  },
  event: {
    method: 'getEvents',
    returnData: 'event',
    requestBody: 'event',
  },
  lead: {
    method: 'getLeadsDateRange',
    returnData: 'lead',
    responseBody: 'default',
  },
  opportunity: {
    method: 'getOpportunitiesDateRange',
    returnData: 'opportunity',
    responseBody: 'default',
  },
  userProfile: {
    method: 'getUserProfiles',
    returnData: 'userProfile',
    responseBody: 'where',
  },
};
