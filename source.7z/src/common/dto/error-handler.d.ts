//
export type ErrorHandlerType<T = any> = {
  source: string;
  path: string;
  message: string;
  error: T;
};
