import axios from 'axios';

export const httpClient = (config: any) => ({
  //
  get: async (url: any) => {
    try {
      const instance = axios.create({
        baseURL: config.baseURL,
        headers: config.headers,
      });
      return await instance.get(url);
    } catch (error) {
      throw error;
    }
  },

  //
  post: async (url: any, body: any) => {
    try {
      const instance = axios.create({
        baseURL: config.baseURL,
        headers: config?.headers || null,
      });
      const result = await instance.post(url, body);
      return result;
    } catch (error) {
      throw error;
    }
  },

  //
  put: async (url: any, body: any) => {
    try {
      const instance = axios.create({
        baseURL: config.baseURL,
        headers: config?.headers || null,
      });
      return await instance.put(url, body);
    } catch (err) {
      const errorTyped: any = err;
      // console.log(error.response.data);
      // console.log(error.response.status);
      // console.log(error.response.headers);
      const error = {
        headers: errorTyped.response.headers,
        status: errorTyped.response.status,
        message: errorTyped.response.data,
      };
      const errorHand = { source: 'HttpClient', path: 'put', error, message: errorTyped.response.data };
      throw errorHand;
    }
  },
});
