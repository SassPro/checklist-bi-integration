import { BigQuery } from '@google-cloud/bigquery';

const bigQueryClient = new BigQuery();

export type BigQuerySchemaFields = {
  name: string;
  type: string;
};
export type BigQueryCreateTable = {
  dataset: string;
  table: string;
  fields: BigQuerySchemaFields[];
};
export type BigQueryInsert = {
  dataset: string;
  table: string;
  data: any[];
};
export type BigQueryTruncate = {
  project: string;
  dataset: string;
  table: string;
};

/**
 * Big Query Adapter
 */
export class BigQueryAdapter {
  //
  /**
   *
   * @param {BigQueryCreateTable} req req
   * @return {object} create
   */
  async createTable(req: BigQueryCreateTable): Promise<unknown> {
    //
    try {
      const datasetRef = bigQueryClient.dataset(req.dataset);
      const tableRef = datasetRef.table(req.table);

      const options = {
        schema: {
          fields: req.fields,
        },
      };

      const result = await tableRef.create(options).catch((error: any) => {
        const err = typeof error === 'string' ? error : JSON.stringify(error);
        const message = { message: `BigQueryAdapter | createTable .catch > ${err}` };
        throw message;
      });

      return result;
    } catch (error) {
      const err = typeof error === 'string' ? error : JSON.stringify(error);
      const message = { message: `BigQueryAdapter | createTable > ${err}` };
      throw message;
    }
  }

  /**
   *
   * @param {BigQueryInsert} insert dataset, table and data
   * @return {string} result
   */
  async insertAll(insert: BigQueryInsert): Promise<unknown> {
    try {
      const data = insert.data;

      if (data?.length == 0) {
        return 'Nenhum registro para inserir';
      }

      const datasetRef = bigQueryClient.dataset(insert.dataset);
      const tableRef = datasetRef.table(insert.table);

      //
      const rows = data?.map((r: any) => {
        return {
          insertId: r.id,
          json: { ...r },
        };
      });

      const options = {
        createInsertId: false,
        raw: true,
      };

      const ins = await tableRef.insert(rows, options).catch((error: any) => {
        const err = typeof error === 'string' ? error : JSON.stringify(error);
        const message = { message: `BigQueryAdapter | insertAll > ${err}` };
        throw message;
      });

      return ins;
    } catch (error) {
      const err = typeof error === 'string' ? error : JSON.stringify(error);
      const message = { message: `BigQueryAdapter | insertAll > ${err}` };
      throw message;
    }
  }

  /**
   *
   * @param {BigQueryRequest} request dataset, table and data
   * @return {object} result
   */
  async truncateTable(request: BigQueryTruncate): Promise<unknown> {
    try {
      const options = {
        query: `truncate table \`${request.project}.${request.dataset}.${request.table}\``,
      };
      const [rows] = await bigQueryClient.query(options).catch((error: any) => {
        const err = typeof error === 'string' ? error : JSON.stringify(error);
        const message = { message: `BigQueryAdapter | truncateTable > ${err}` };
        throw message;
      });
      return rows;
    } catch (error) {
      const err = typeof error === 'string' ? error : JSON.stringify(error);
      const message = { message: `BigQueryAdapter | truncateTable > ${err}` };
      throw message;
    }
  }
}
