import { IntegrationRequest } from '../integration/dto/integration-request';
const { CloudTasksClient } = require('@google-cloud/tasks');

const PROJECT_ID = process.env.PROJECT_ID || '';
const QUEUE_NAME = process.env.QUEUE_NAME || '';
const QUEUE_LOCATION = process.env.QUEUE_LOCATION || '';

/**
 * Tasks
 */
export class Task {
  private baseFunctionUrl: string;

  /**
   *
   * @param {TaskCreate} task
   */
  constructor() {
    this.baseFunctionUrl = `https://us-central1-${PROJECT_ID}.cloudfunctions.net/`;
  }

  /**
   *
   * @param {TaskAdd} request request
   * @return {objetc} task create
   */
  async createHttpPost(request: IntegrationRequest) {
    try {
      const client = new CloudTasksClient();
      const parent = client.queuePath(PROJECT_ID, QUEUE_LOCATION, QUEUE_NAME);

      const bodyString = JSON.stringify(request.body || '');
      const payload = Buffer.from(bodyString).toString('base64');

      const task = {
        httpRequest: {
          httpMethod: 'POST',
          url: `${this.baseFunctionUrl}${request.body.endpoint}`,
          headers: {
            'Content-Type': 'application/json',
          },
          body: payload,
        },
      };

      return await client.createTask({ parent, task });
    } catch (error) {
      const errorTyped: any = error;
      const message = {
        message: `Task | createHttpPost > ${errorTyped.message}`,
      };
      throw message;
    }
  }
}
