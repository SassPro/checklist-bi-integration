import admin = require('firebase-admin');
import { ErrorHandlerType } from '../common/dto/error-handler';

//
//
//
export type FirestoreAdapterDto = {
  collectionID: string;
  documentID: string;
  document?: any;
  where?: {
    field: string;
    operator: FirebaseFirestore.WhereFilterOp;
    value: string;
  };
};

/**
 * Big Query Adapter
 */
export class FirestoreAdapter {
  //
  private db: FirebaseFirestore.Firestore;

  /**
   *
   */
  constructor() {
    admin.apps.length ? admin.app() : admin.initializeApp();
    this.db = admin.firestore();
  }

  /**
   *
   * @param {FirestoreAdapterDto} request request
   * @return {object} document
   */
  async findById<T>(request: FirestoreAdapterDto): Promise<T> {
    try {
      const collectionRef = this.db.collection(request.collectionID);
      const document = collectionRef.doc(request.documentID.toString()).get();

      return (await document).data() as T;
    } catch (error) {
      const errorTyped: any = error;
      const errorHand: ErrorHandlerType<any> = {
        source: 'FirestoreAdapter',
        path: 'get',
        message: errorTyped.message,
        error,
      };
      throw errorHand;
    }
  }

  /**
   *
   * @param {FirestoreAdapterDto} request request
   * @return {T} result
   */
  async where<T>(request: FirestoreAdapterDto): Promise<T[]> {
    try {
      const collectionRef = this.db.collection(request.collectionID);

      const field = request?.where?.field.toString() || '';
      const operator = request?.where?.operator || '==';
      const value = request?.where?.value || 0;

      const snapshot = await collectionRef.where(field, operator, value).get();

      const document: T[] = [];
      snapshot.forEach((doc) => {
        document.push(doc.data() as T);
      });

      return document;
    } catch (error) {
      const errorTyped: any = error;
      const errorHand: ErrorHandlerType<any> = {
        source: 'FirestoreAdapter',
        path: 'where',
        message: errorTyped.message,
        error,
      };
      throw errorHand;
    }
  }

  /**
   *
   * @param {FirestoreAdapterDto} request request
   * @return {object} result
   */
  async save<T>(request: FirestoreAdapterDto): Promise<FirebaseFirestore.WriteResult> {
    try {
      const docId = request.documentID?.toString() || 'aa';

      const collectionRef = this.db.collection(request.collectionID);

      const isCreated = await this.findById<T>(request);

      if (isCreated) {
        return await collectionRef.doc(docId).update(request.document);
      } else {
        return await collectionRef.doc(docId).set(request.document);
      }
    } catch (error) {
      const errorTyped: any = error;
      const errorHand: ErrorHandlerType<any> = {
        source: 'FirestoreAdapter',
        path: 'save',
        message: errorTyped.message || '',
        error,
      };
      throw errorHand;
    }
  }

  /**
   *
   * @param {FirestoreAdapterDto} request request
   * @return {object} delete
   */
  async delete(request: FirestoreAdapterDto): Promise<FirebaseFirestore.WriteResult> {
    try {
      const collectionRef = this.db.collection(request.collectionID);
      return await collectionRef.doc(request.documentID.toString()).delete();
    } catch (error) {
      const errorTyped: any = error;
      const errorHand: ErrorHandlerType = {
        source: 'FirestoreAdapter',
        path: 'delete',
        message: errorTyped.message,
        error,
      };
      throw errorHand;
    }
  }
}
