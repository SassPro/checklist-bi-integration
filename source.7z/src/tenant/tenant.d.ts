export type SchemaRequest = {
  entity: string;
};

export type SchemaResponse = {
  name: string;
  type: string;
};
