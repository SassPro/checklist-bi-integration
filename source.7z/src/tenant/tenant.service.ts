import admin = require('firebase-admin');
import { SchemaRequest, SchemaResponse } from './tenant';

/**
 * Schema
 */
export class TenantService {
  //
  private db: FirebaseFirestore.Firestore;

  /**
   *
   */
  constructor() {
    admin.apps.length ? admin.app() : admin.initializeApp();
    this.db = admin.firestore();
  }

  /**
   *
   * @param {SchemaRequest} getSchema get
   * @return {SchemaResponse[]} res
   */
  async getSchema(getSchema: SchemaRequest): Promise<SchemaResponse[]> {
    //
    const SCHEMA = process.env.FIRESTORE_SCHEMA_COLLECTION || 'entity-schemas';
    const entity = getSchema.entity || '';

    try {
      // Collection Ref
      const collRef = this.db.collection(SCHEMA);

      // Document - Get
      const docRef = await collRef.doc(entity).get();

      // Data
      const entityFileds = docRef.data() || {};

      // result array
      const fields: SchemaResponse[] = [];

      // result
      Object.keys(entityFileds).forEach((k) => {
        const name = k.trim();
        const type = entityFileds[k] || 'STRING';
        fields.push({ name, type });
      });

      return fields;
    } catch (error) {
      const message = { message: `Tenant | getSchema > ${error}` };
      throw message;
    }
  }
}
